import { api } from "@/app/lib/api";

export type Product = {
  _id: string;
  title: string;
  description?: string;
  imageCover: string;
  images?: string[];
  price: number;
  priceAfterDiscount?: number;
  ratingsAverage?: number;
  category?: { _id: string; name: string };
  brand?: { _id: string; name: string };
  sold?: number;
  createdAt?: string;
};

type ProductsRes = { results?: number; data?: Product[] } & { data?: any };

/** Generic list */
export async function getProducts(params: Record<string, string | number> = {}) {
  const qs = new URLSearchParams(Object.entries(params).map(([k, v]) => [k, String(v)]));
  const res = await api<{ results: number; data: Product[] }>(`/api/v1/products?${qs.toString()}`);
  return res.data;
}

/** Home sections */
export async function getFlashSales(limit = 6) {
  // "Flash" = best selling right now
  return getProducts({ limit, sort: "-sold,-ratingsAverage" });
}
export async function getBestSelling(limit = 8) {
  return getProducts({ limit, sort: "-sold,-ratingsAverage" });
}
export async function getExplore(limit = 8, page = 1) {
  return getProducts({ limit, page, sort: "-ratingsAverage" });
}
export async function getNewArrival(limit = 4) {
  return getProducts({ limit, sort: "-createdAt" });
}

/** Details */
export async function getProductById(id: string) {
  const res = await api<{ data: Product }>(`/api/v1/products/${id}`);
  return res.data;
}
