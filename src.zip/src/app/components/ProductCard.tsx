"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useTransition } from "react";
import type { Product } from "@/app/lib/products-api";
import { addToCart } from "@/app/lib/cart-api";
import { addToWishlist, removeFromWishlist } from "@/app/lib/wishlist-api";

function IconHeart({ filled=false, className="" }: { filled?: boolean; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill={filled ? "currentColor" : "none"} stroke="currentColor">
      <path strokeWidth="1.6"
        d="M20.8 4.6a5 5 0 0 0-7.1 0L12 6.3l-1.7-1.7a5 5 0 1 0-7 7l8.7 8.7c.3.3.7.3 1 0l8.7-8.7a5 5 0 0 0 0-7z" />
    </svg>
  );
}

export default function ProductCard({ p }: { p: Product }) {
  const price = p.priceAfterDiscount ?? p.price;
  const old = p.priceAfterDiscount ? p.price : undefined;

  const [imgSrc, setImgSrc] = useState<string>(p.imageCover || "/placeholder.png");
  const [wish, setWish] = useState<boolean>(false);
  const [pending, startTransition] = useTransition();

  const onAddToCart = () =>
    startTransition(async () => {
      try {
        await addToCart(p._id);
        alert("Added to cart ✅");
      } catch (e: any) {
        alert(e?.message || "Could not add to cart");
      }
    });

  const toggleWish = () =>
    startTransition(async () => {
      try {
        if (wish) {
          await removeFromWishlist(p._id);
          setWish(false);
        } else {
          await addToWishlist(p._id);
          setWish(true);
        }
      } catch (e: any) {
        alert(e?.message || "Wishlist failed");
      }
    });

  return (
    <div className="group rounded-md border border-neutral-100 bg-white p-3">
      <div className="relative">
        {/* wishlist button (top-right) */}
        <button
          aria-label="Toggle wishlist"
          onClick={toggleWish}
          className="absolute right-2 top-2 z-10 rounded-md bg-white/90 p-1 text-neutral-600 hover:text-brand-600"
        >
          <IconHeart filled={wish} className="h-5 w-5" />
        </button>

        <Link href={`/products/${p._id}`} className="block">
          <div className="relative aspect-[4/3] w-full overflow-hidden rounded-md bg-neutral-50">
            <Image
              src={imgSrc}
              alt={p.title}
              fill
              sizes="(min-width:1024px) 16vw, (min-width:640px) 30vw, 45vw"
              className="object-contain transition-transform duration-300 group-hover:scale-105"
              onError={() => setImgSrc("/placeholder.png")}
              priority={false}
            />
          </div>
        </Link>
      </div>

      <Link href={`/products/${p._id}`} className="mt-3 block space-y-1">
        <div className="line-clamp-1 text-sm font-medium text-neutral-700">{p.title}</div>
        <div className="flex items-center gap-2">
          <span className="text-brand-600 font-semibold">${price}</span>
          {old && <span className="text-xs text-neutral-400 line-through">${old}</span>}
        </div>
        {p.ratingsAverage ? (
          <div className="text-xs text-yellow-600">★ {p.ratingsAverage.toFixed(1)}</div>
        ) : null}
      </Link>

      <button
        className="mt-3 inline-flex h-9 w-full items-center justify-center rounded-md bg-neutral-900 text-xs font-medium text-white transition-colors hover:bg-neutral-700 disabled:opacity-60"
        onClick={onAddToCart}
        disabled={pending}
      >
        {pending ? "Adding..." : "Add To Cart"}
      </button>
    </div>
  );
}
