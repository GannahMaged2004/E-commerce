"use client";
import Image from "next/image";
import Link from "next/link";
import { Category } from "@/app/lib/categories-api";

export default function CategoryPill({ c }: { c: Category }) {
  return (
    <Link
      href={`/categories/${c._id}`}
      className="flex flex-col items-center justify-center rounded-md border border-neutral-200 bg-white p-4 text-sm hover:border-neutral-400"
    >
      <div className="relative mb-2 h-12 w-12">
        {c.image ? (
          <Image src={c.image} alt={c.name} fill className="object-contain" />
        ) : (
          <div className="grid h-full w-full place-items-center rounded bg-neutral-100 text-xs text-neutral-500">
            {c.name[0]}
          </div>
        )}
      </div>
      <span className="text-neutral-600">{c.name}</span>
    </Link>
  );
}
