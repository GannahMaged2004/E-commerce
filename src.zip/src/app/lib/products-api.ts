// src/app/lib/products-api.ts
import { api } from "./api";

export type Product = {
  _id: string;
  title: string;
  imageCover: string;
  price: number;
  priceAfterDiscount?: number;
  ratingsAverage?: number;
  category?: { name: string; _id: string };
  brand?: { name: string; _id: string };
};

/** Generic fetcher */
async function fetchProducts(params: string) {
  const res = await api<{ results?: number; data?: { products?: Product[] } }>(
    `/api/v1/products?${params}`
  );
  // RouteMISR returns { results, data: { products: [...] } }
  const list = res?.data?.products;
  return Array.isArray(list) ? list : ([] as Product[]);
}

/** Flash sales: newest with (optionally) discount first */
export function getFlashSales(limit = 6) {
  // sort by -createdAt, then priceAfterDiscount if the API supports
  return fetchProducts(`limit=${limit}&sort=-createdAt`);
}

/** Best selling: high rating first (or sold count if your API supports it) */
export function getBestSelling(limit = 8) {
  // RouteMISR supports sort=-ratingsAverage
  return fetchProducts(`limit=${limit}&sort=-ratingsAverage`);
}

/** Explore: paginated general listing */
export function getExplore(limit = 8, page = 1) {
  return fetchProducts(`limit=${limit}&page=${page}`);
}

/** New arrivals: newest products */
export function getNewArrival(limit = 4) {
  return fetchProducts(`limit=${limit}&sort=-createdAt`);
}

/** Product details */
export async function getProductById(id: string) {
  const res = await api<{ data?: { product?: Product }; product?: Product }>(
    `/api/v1/products/${id}`
  );
  return res?.data?.product ?? (res as any)?.product ?? null;
}
