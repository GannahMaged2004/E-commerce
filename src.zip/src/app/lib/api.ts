// src/app/lib/api.ts
export const API_BASE = (process.env.NEXT_PUBLIC_API_BASE || "").replace(/\/+$/, ""); // no trailing slash

function getToken() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("token");
}

export function setToken(token: string | null) {
  if (typeof window === "undefined") return;
  if (token) localStorage.setItem("token", token);
  else localStorage.removeItem("token");
}

export async function api<T>(
  path: string,
  opts: RequestInit & { auth?: boolean } = {}
): Promise<T> {
  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...(opts.headers || {}),
  };

  if (opts.auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  // Ensure exactly one slash between base and path
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const url = `${API_BASE}${normalizedPath}`;

  // 🔧 IMPORTANT: use the normalized `url` (you were still using `${API_BASE}${path}`)
  const res = await fetch(url, { ...opts, headers });
  const json = await res.json().catch(() => ({}));

  if (!res.ok) {
    const message = json?.message || json?.errors?.msg || `Request failed (${res.status})`;
    throw new Error(message);
  }

  return json as T;
}
