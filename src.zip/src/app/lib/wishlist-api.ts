import { api } from "./api";

export type WishlistResponse = { status: string; count: number; data: string[] }; // product ids

export function getWishlist() {
  return api<WishlistResponse>("/api/v1/wishlist", { auth: true });
}
export function addToWishlist(productId: string) {
  return api<WishlistResponse>("/api/v1/wishlist", {
    method: "POST",
    body: JSON.stringify({ productId }),
    auth: true,
  });
}
export function removeFromWishlist(productId: string) {
  return api<WishlistResponse>(`/api/v1/wishlist/${productId}`, {
    method: "DELETE",
    auth: true,
  });
}
